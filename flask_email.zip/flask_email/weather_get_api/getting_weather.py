import re
import requests


def get_weather(city: str, api_id: str):
    """Get weather to city name"""
    url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_id}&units=metric'
    response = requests.get(url)

    if response.status_code != 200:
        message = f'openweathermap.org returned non-200 code. Actual code is: {response.status_code},' \
                  f' message is: {response.json()["message"]}'
        raise RuntimeError(message)

    return response.json()


def determine_temperature(city: dict):
    """Determine temperature"""
    temperature = city['main']['temp']
    return 'warm' if temperature > 20 else 'cold'


def get_weather_icon(icon_name: str):
    """Get weather icon"""
    icon_url = f'http://openweathermap.org/img/wn/{icon_name}.png'
    return icon_url


def parse_weather_data(city_weather: dict):
    """Parse weather data"""
    icon_name = city_weather['weather'][0]['icon']

    icon = get_weather_icon(icon_name)
    latitude = city_weather['coord']['lat']
    longitude = city_weather['coord']['lon']
    sky = city_weather['weather'][0]['description']
    temperature = city_weather['main']['temp']
    wind_speed = city_weather['wind']['speed']
    country = city_weather['sys']['country']

    weather_data = {
        'icon': icon,
        'latitude': latitude,
        'longitude': longitude,
        'sky': sky,
        'temperature': temperature,
        'wind_speed': wind_speed,
        'country': country
    }
    return weather_data


def main(city_name: str, api_id: str):
    """Main controller"""
    try:
        city_weather = get_weather(city_name, api_id)
    except RuntimeError as error:
        message = re.findall(r'(?<=message is:).*', str(error)).pop().title()
        return {'error': message}
    weather_data = parse_weather_data(city_weather)
    return weather_data


# API_ID = '33b7243755fa4a1925fa621e8ee132aa'
# CITY = 'tokyo'
# print(main(CITY, API_ID))

