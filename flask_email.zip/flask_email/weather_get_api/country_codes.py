import json
from datapackage import Package


def get_codes():
    """Get list of country codes"""
    package = Package('https://datahub.io/core/country-list/datapackage.json')

    for resource in package.resources:
        if resource.descriptor['datahub']['type'] == 'derived/csv':
            return resource.read()
    return None


def prepare_data_to_json(codes_data: list[list[str]]):
    """Prepare data to json"""
    json_data = []
    for country_code in codes_data:
        country = {
            'code': country_code[1],
            'name': country_code[0]
        }
        json_data.append(country)
    return json_data


def write_codes_data_to_json(json_data: list[dict[str]], filename: str = 'countries_code.json'):
    """Write data to json file"""
    with open(filename, 'w') as json_file:
        json.dump(json_data, json_file, indent=4)
    return True


def main():
    """Main controller"""
    codes = get_codes()
    if not codes:
        raise RuntimeError('Country codes data not found')
    json_data = prepare_data_to_json(codes)
    write_json = write_codes_data_to_json(json_data)
    return write_json


print(main())


