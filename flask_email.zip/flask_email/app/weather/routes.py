from flask import render_template, redirect, url_for, flash, request, current_app

from app.weather import weather
from app.weather.forms import CityForm
from weather_get_api.getting_weather import main as get_weather


@weather.route('/weather', methods=['POST', 'GET'])
def index():
    """Weather page"""
    form = CityForm()

    if form.validate_on_submit():
        api_id = current_app.config['WEATHER_API_ID']

        city_name = form.city_name.data
        city_weather = get_weather(city_name, api_id)
        if 'error' in city_weather:
            flash(city_weather['error'])
            return redirect(url_for('weather.index'))
        print(city_weather)

    return render_template(
        'weather/get_weather.html',
        title='Get city weather',
        form=form
    )
