# Inteview task #1

Given a CSV file with 2 columns: `country` and `person`, group the result by the country, and print out all the people for each country + people count.

Result sample:
```json
{
  "Ukraine": {
    "people": ["Vlad", "Yaroslav", ...],
    "count": 2
  }
  "USA": {
    "people": ["Bob", "Chris", ...],
    "count": 2
   },
   ...
}
```

Use CSV file [provided in this repository](data.csv).
