import examples


if __name__ == '__main__':
    print(examples.__file__)
